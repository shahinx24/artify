export const ENV = {
  USER_KEY: "artify_user",
  CART_KEY: "artify_cart"
};