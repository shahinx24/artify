import Connect from "./router/Connect.jsx";
import "./App.css";

export default function App() {

  return (
    <>
    <Connect />
    </>
  );
}