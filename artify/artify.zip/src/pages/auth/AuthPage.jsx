import { useLocation, useNavigate } from "react-router-dom";
import AuthForm from "../../components/form/AuthForm";
import AuthSwitch from "../../components/form/AuthSwitch";
import { useAuth } from "../../hooks/useAuth";

export default function AuthPage({ showToast }) {
  const { form, handleChange, login, register } = useAuth(showToast);
  const location = useLocation();
  const navigate = useNavigate();

  const isLogin = location.pathname === "/login";

  const handleSubmit = async () => {
    const res = isLogin ? await login() : await register();
    if (res && isLogin) {
      navigate("/");
    }
  };

  return (
    <>
      <AuthForm
        title={isLogin ? "Welcome Back" : "Create Account"}
        buttonText={isLogin ? "LOGIN" : "REGISTER"}
        onSubmit={handleSubmit}
        onChange={handleChange}
        values={form}
        fields={[
          { name: "email", type: "email", placeholder: "Email" },
          { name: "pass", type: "password", placeholder: "Password" },
          ...(!isLogin
            ? [{ name: "confirm", type: "password", placeholder: "Confirm Password" }]
            : [])
        ]}
      />

      <AuthSwitch
        text={isLogin ? "Don't have an account?" : "Already have an account?"}
        actionText={isLogin ? "Register" : "Login"}
        onClick={() =>
          navigate(isLogin ? "/register" : "/login")
        }
      />
    </>
  );
}