import { getUser } from "../utils/userHelpers";
import { Link } from "react-router-dom";
import wishlist from "../assets/icons/wishlist.svg";

export default function WishlistButton() {
  const user = getUser();
  const count = user?.wishlist?.reduce((sum, item) => sum + (item.qty || 1), 0) || 0;

  return (
    <Link to="/wishlist">
      <button className="wishlist-button">
        <img src={wishlist} alt="wishlist" className="wishlist-icon" />
        {count > 0 && <span className="wishlist-badge">{count}</span>}
      </button>
    </Link>
  );
}