export const ENV = {
  API_BASE_URL: "http://localhost:3000",
  USER_KEY: "artify_user",
  CART_KEY: "artify_cart"
};