export const products = [
  {
    id: 1,
    name: "Round Brush",
    price: 120,
    category: "Brushes",
    img: "/brush.jpg"
  },
  {
    id: 2,
    name: "Acrylic Colors",
    price: 250,
    category: "Colors",
    img: "/colors.jpg"
  },
  {
    id: 3,
    name: "Canvas Board",
    price: 180,
    category: "Canvas",
    img: "/canvas.jpg"
  },
  {
    id: 4,
    name: "Sketchbook",
    price: 90,
    category: "Drawing Paper",
    img: "/paper.jpg"
  }
];
